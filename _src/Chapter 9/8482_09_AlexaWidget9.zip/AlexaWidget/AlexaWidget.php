<?php
/**
 * Piwik - Open source web analytics
 * 
 * @link http://piwik.org
 * @license http://www.gnu.org/licenses/gpl-3.0.html GPL v3 or later
 * @version $Id: AlexaWidget.php 4528 2011-04-21 00:04:29Z vipsoft $
 * 
 * @category Piwik_Plugins
 * @package Piwik_AlexaWidget
 */

/**
 *
 * @package Piwik_AlexaWidget
 */
class Piwik_AlexaWidget extends Piwik_Plugin
{
	/**
	 * Return information about this plugin.
	 *
	 * @see Piwik_Plugin
	 *
	 * @return array
	 */
	public function getInformation()
	{
		return array(
			'description' => Piwik_Translate('My Alexa Widget'),
			'author' => 'Me',
			'author_homepage' => 'http://me.org/',
			'version' => '0.1',
		);
	}

}

Piwik_AddWidget('Example Widgets', 'Alexa Traffic Stats', 'AlexaWidget', 'alexa');

/**
 *
 * @package Piwik_AlexaWidget
 */
class Piwik_AlexaWidget_Controller extends Piwik_Controller
{

	/**
	 * Simple alexa statistics output
	 *
	 */

	function alexa()
	{
		echo '<img src="http://traffic.alexa.com/graph?u=www.stephanmiller.com&c=1&w=400&h=220&y=r&r=3m&b=e6f3fc" />';
	}
}
