<?php 
// -- Piwik Tracking API init -- 
require_once "/PATH_TO/PiwikTracker.php";
PiwikTracker::$URL = 'http://YOUR_PIWIK_URL';
?>
