chown -R www-data:www-data piwik
chmod -R 0755 piwik