$(document).ready(function(){
	$('#myShoutBoxButton').click(function() {
	   piwiTracker.trackPageView('ShoutBoxClick');
	});
});