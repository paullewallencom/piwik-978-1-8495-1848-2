<!-- Piwik --> 
<script type="text/javascript">
var protoCol = ('https:' == document.location.protocol ? 'https://' : 'http://');
document.write(unescape("%3Cscript src='" + protoCol + "URL_1/piwik.js' type='text/javascript'%3E%3C/script%3E"));
</script><script type="text/javascript">
try {
var piwikTracker1 = Piwik.getTracker(protoCol + URL_1/piwik.php", 1);
piwikTracker1.trackPageView();
var piwikTracker2 = Piwik.getTracker(protoCol + URL_2/piwik.php", 4);
piwikTracker2.trackPageView();
} catch( err ) {}
</script>
<!-- End Piwik Tracking Code -->